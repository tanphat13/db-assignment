
    <link href="setting-loginform.css" rel="stylesheet">
    <form class="loginform" action="login.processing.php" method="post">
        <fieldset> 
            <legend> Login Form </legend> <br> 
            <label for="username">Username:</label>
            <input type="text" id="username" name="username" required><br>
            <label for="password">Your Password:</label>
            <input type="password" id="password" name="password" required><br>
            <input type="submit" >
        </fieldset>
    </form>