<!DOCTYPE HTML>
<html>
<body>

<?php
    $name = $_POST['username'];
    $email = $_POST['password'];

    echo "Name: $name";
    echo "<br>";
    echo "Email: $email";
?>

</body>
</html>